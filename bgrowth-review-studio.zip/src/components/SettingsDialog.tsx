import React from 'react';
import { useReviewStore } from '../data/store';
import { Settings, RefreshCw, Trash2, ShieldAlert, Key } from 'lucide-react';
import { motion } from 'motion/react';

interface SettingsDialogProps {
  onClose: () => void;
}

export const SettingsDialog: React.FC<SettingsDialogProps> = ({ onClose }) => {
  const { clearAllData } = useReviewStore();

  const handleResetToDefault = () => {
    if (confirm('Tem certeza de que deseja reverter todas as alterações e carregar os modelos originais do BGrowth Review Studio™?')) {
      clearAllData();
      // Reload page to re-seed default data
      window.location.reload();
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center z-50 p-4 select-none font-sans">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white border border-slate-200 rounded-2xl shadow-2xl max-w-md w-full flex flex-col overflow-hidden"
      >
        <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-white shrink-0">
          <div className="flex items-center space-x-2">
            <Settings className="w-5 h-5 text-slate-700" />
            <h3 className="font-display font-extrabold text-slate-900 tracking-tight text-sm">
              Configurações do Workspace Review Studio™
            </h3>
          </div>
          <button
            id="btn-close-settings"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 transition text-xs font-semibold"
          >
            Fechar
          </button>
        </div>

        <div className="p-6 space-y-5 text-xs text-slate-600">
          {/* Security details panel */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
            <div className="flex items-center space-x-1.5 font-bold text-slate-800">
              <Key className="w-4 h-4 text-[#1061EC]" />
              <span>Segurança da Chave de API do Gemini</span>
            </div>
            <p className="leading-relaxed">
              O BGrowth Review Studio opera em um layout full-stack seguro. Todas as requisições ao Gemini 3.5 Flash são roteadas através de proxies no servidor Express, o que significa que a <code>GEMINI_API_KEY</code> nunca é exposta aos navegadores clientes ou registros de rede.
            </p>
          </div>

          {/* Reset / Destructive operations */}
          <div className="space-y-3">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Ações Destrutivas</span>
            
            <div className="border border-slate-150 rounded-xl p-4 flex flex-col space-y-3">
              <div className="flex items-start space-x-2">
                <ShieldAlert className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <h4 className="font-bold text-slate-800">Redefinir Dados do Local Storage</h4>
                  <p className="text-[11px] leading-relaxed text-slate-500">
                    Apaga todos os comentários personalizados, checklists, telas adicionadas e redefine de volta aos modelos interativos oficiais do BGrowth.
                  </p>
                </div>
              </div>

              <button
                id="btn-reset-defaults"
                onClick={handleResetToDefault}
                className="w-full py-2 bg-slate-100 hover:bg-red-50 text-slate-700 hover:text-red-700 font-bold border border-slate-200 hover:border-red-200 rounded-lg transition text-center flex items-center justify-center space-x-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Reverter para Modelos Iniciais</span>
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
