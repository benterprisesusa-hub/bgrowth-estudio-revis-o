import React, { useState } from 'react';
import { useReviewStore } from '../data/store';
import { Monitor, Upload, FileText, Check } from 'lucide-react';
import { motion } from 'motion/react';

interface NewScreenDialogProps {
  onClose: () => void;
}

export const NewScreenDialog: React.FC<NewScreenDialogProps> = ({ onClose }) => {
  const { addScreen } = useReviewStore();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [version, setVersion] = useState('v1.0.0');
  
  // Choose between interactive templates vs custom files
  const [useTemplate, setUseTemplate] = useState<boolean>(true);
  const [templateSelection, setTemplateSelection] = useState<'dashboard' | 'login' | 'crm'>('dashboard');
  const [uploadedBase64, setUploadedBase64] = useState<string>('');
  const [uploadedFileName, setUploadedFileName] = useState<string>('');

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setUploadedBase64(event.target.result as string);
          setUploadedFileName(file.name);
          setTitle(file.name.split('.')[0] || 'Uploaded Screen');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    const screenshotData = useTemplate ? templateSelection : uploadedBase64;
    if (!screenshotData) {
      alert('Por favor, carregue uma imagem de captura de tela primeiro!');
      return;
    }

    addScreen(title, description, version, screenshotData);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center z-50 p-4 select-none font-sans">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white border border-slate-200 rounded-2xl shadow-2xl max-w-lg w-full flex flex-col overflow-hidden"
      >
        <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-white shrink-0">
          <div className="flex items-center space-x-2">
            <Monitor className="w-5 h-5 text-blue-600" />
            <h3 className="font-display font-extrabold text-slate-900 tracking-tight text-sm">
              Adicionar Nova Tela de Interface
            </h3>
          </div>
          <button
            id="btn-close-new-screen"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 transition text-xs font-semibold"
          >
            Cancelar
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {/* Tabs for templates vs files */}
          <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl">
            <button
              type="button"
              id="btn-tab-template"
              onClick={() => setUseTemplate(true)}
              className={`py-1.5 font-bold rounded-lg transition ${
                useTemplate ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              Protótipos do Tailwind
            </button>
            <button
              type="button"
              id="btn-tab-upload"
              onClick={() => setUseTemplate(false)}
              className={`py-1.5 font-bold rounded-lg transition ${
                !useTemplate ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              Enviar Imagem Personalizada
            </button>
          </div>

          {/* Template Choice selection cards */}
          {useTemplate ? (
            <div className="space-y-2">
              <label className="block text-slate-400 font-bold uppercase tracking-wider">Escolher Modelo de Protótipo</label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: 'dashboard', title: 'Painel SaaS', desc: 'Métricas SaaS, gráficos' },
                  { id: 'login', title: 'Login Interativo', desc: 'Validação de autenticação, divisões' },
                  { id: 'crm', title: 'Portal CRM', desc: 'Grades de dados, buscas' },
                ].map((tpl) => (
                  <button
                    key={tpl.id}
                    type="button"
                    id={`btn-select-tpl-${tpl.id}`}
                    onClick={() => {
                      setTemplateSelection(tpl.id as any);
                      setTitle(tpl.title);
                      setDescription(`Verificação visual de UI do protótipo padrão de ${tpl.title}.`);
                    }}
                    className={`p-3 border rounded-xl text-left transition flex flex-col justify-between h-24 ${
                      templateSelection === tpl.id 
                        ? 'border-blue-500 bg-blue-50/20' 
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex justify-between items-start w-full">
                      <span className="font-bold text-slate-800 leading-none">{tpl.title}</span>
                      {templateSelection === tpl.id && <Check className="w-3.5 h-3.5 text-blue-600 shrink-0" />}
                    </div>
                    <span className="text-[10px] text-slate-400 leading-normal">{tpl.desc}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            // Custom drag/drop image uploader
            <div className="space-y-2">
              <label className="block text-slate-400 font-bold uppercase tracking-wider">Enviar Arquivo de Captura de Tela</label>
              <label className="border-2 border-dashed border-slate-200 hover:border-blue-500 hover:bg-blue-50/10 rounded-xl p-5 flex flex-col items-center justify-center cursor-pointer transition">
                <Upload className="w-7 h-7 text-slate-400 mb-2" />
                <span className="font-bold text-slate-700">
                  {uploadedFileName ? `Anexado: ${uploadedFileName}` : 'Selecione ou solte o arquivo de imagem...'}
                </span>
                <span className="text-[10px] text-slate-400 mt-1">Suporta JPEG, PNG, WEBP ou SVG</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          )}

          <div className="space-y-1.5">
            <label className="block text-slate-400 font-bold uppercase tracking-wider">Título da Tela</label>
            <input
              id="input-new-screen-title"
              type="text"
              placeholder="Ex: Console do Painel - v2"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs outline-none focus:border-blue-500 transition"
            />
          </div>

          <div className="space-y-1.5">
            <label className="block text-slate-400 font-bold uppercase tracking-wider">Versão Inicial de Revisão da Tela</label>
            <input
              id="input-new-screen-version"
              type="text"
              placeholder="Ex: v2.1.0"
              value={version}
              onChange={(e) => setVersion(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs outline-none focus:border-blue-500 transition"
            />
          </div>

          <div className="space-y-1.5">
            <label className="block text-slate-400 font-bold uppercase tracking-wider">Descrição / Limites de Escopo</label>
            <textarea
              id="textarea-new-screen-desc"
              placeholder="Identifique requisitos específicos de revisão, bugs conhecidos ou referências de design..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full h-20 px-3 py-2 border border-slate-200 rounded-lg text-xs outline-none resize-none focus:border-blue-500 transition"
            />
          </div>

          <button
            id="btn-submit-new-screen"
            type="submit"
            className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs transition shadow-md shadow-blue-500/15"
          >
            Provisionar Visualização da Tela
          </button>
        </form>
      </motion.div>
    </div>
  );
};
