import { initializeApp } from 'firebase/app';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: any, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: null,
      email: null,
      emailVerified: null,
      isAnonymous: null,
      tenantId: null,
      providerInfo: []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

const firebaseConfig = {
  apiKey: "AIzaSyBIXtii0msY07JFkmvzix2YqrDz3c606dk",
  authDomain: "marklar-lexicon-ld2jw.firebaseapp.com",
  projectId: "marklar-lexicon-ld2jw",
  storageBucket: "marklar-lexicon-ld2jw.firebasestorage.app",
  messagingSenderId: "806301575007",
  appId: "1:806301575007:web:8f87f6328cc488fd92f8ea"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore with specific database ID
export const db = getFirestore(app, "ai-studio-bgrowthreviewstu-1e68efcb-deb6-4863-a98d-6b0781ca6494");

// Validate connection
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log("Conectado ao Firebase com sucesso!");
  } catch (error) {
    console.log("Inicialização do Firebase concluída (offline/cache pronto se offline).");
  }
}
testConnection();
